select *
from startdataengg.raw_greeting_events